package com.pixelcutaero.editor;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String BASE_URL = "https://" + HOST;
    private static final int MEDIA_PERMISSION_REQUEST = 4101;
    private static final int FILE_PICK_REQUEST = 4102;

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private final Map<String, Uri> mediaUris = new ConcurrentHashMap<>();
    private final Map<String, String> reverseMediaIds = new ConcurrentHashMap<>();

    private Uri exportUri;
    private OutputStream exportStream;
    private File legacyExportFile;
    private String exportName;
    private final Object exportLock = new Object();

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(6, 34, 63));
        w.setNavigationBarColor(Color.rgb(2, 13, 34));
        if (Build.VERSION.SDK_INT >= 29) {
            w.setNavigationBarContrastEnforced(false);
            w.setStatusBarContrastEnforced(false);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(2, 13, 34));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentView(webView);
        // Android 15 enforces edge-to-edge for targetSdk 35; keep editor controls
        // inside safe system-bar and display-cutout insets.
        if (Build.VERSION.SDK_INT >= 35) {
            webView.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets safe = insets.getInsets(
                        android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
            webView.requestApplyInsets();
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!"https".equalsIgnoreCase(u.getScheme()) || !HOST.equalsIgnoreCase(u.getHost())) {
                    return errorResponse(403, "Forbidden");
                }
                String path = u.getPath() == null ? "/" : u.getPath();
                if (path.startsWith("/media/")) {
                    String token = path.substring("/media/".length());
                    return streamMedia(token, request.getRequestHeaders());
                }
                if (path.startsWith("/assets/")) {
                    String asset = path.substring("/assets/".length());
                    try {
                        InputStream in = getAssets().open(asset);
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Cache-Control", "no-cache");
                        headers.put("Access-Control-Allow-Origin", BASE_URL);
                        return new WebResourceResponse(mimeForName(asset), "UTF-8", 200, "OK", headers, in);
                    } catch (IOException e) {
                        return errorResponse(404, "Not Found");
                    }
                }
                return errorResponse(404, "Not Found");
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !"https".equalsIgnoreCase(u.getScheme()) || !HOST.equalsIgnoreCase(u.getHost());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "model/gltf-binary", "application/octet-stream", "application/zip",
                        "video/*", "image/*", "audio/*"
                });
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(intent, FILE_PICK_REQUEST);
                } catch (Exception e) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No file picker is available", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        WebView.setWebContentsDebuggingEnabled(false);
        webView.loadUrl(BASE_URL + "/assets/index.html");
    }

    private static WebResourceResponse errorResponse(int code, String message) {
        return new WebResourceResponse("text/plain", "UTF-8", code, message,
                new HashMap<>(), new ByteArrayInputStream(message.getBytes(StandardCharsets.UTF_8)));
    }

    private String mimeForName(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js")) return "application/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        return "application/octet-stream";
    }

    private WebResourceResponse streamMedia(String token, Map<String, String> requestHeaders) {
        Uri uri = mediaUris.get(token);
        if (uri == null) return errorResponse(404, "Media not registered");
        android.os.ParcelFileDescriptor pfd = null;
        try {
            pfd = getContentResolver().openFileDescriptor(uri, "r");
            if (pfd == null) return errorResponse(404, "Media unavailable");
            long length = pfd.getStatSize();
            String range = null;
            if (requestHeaders != null) {
                for (Map.Entry<String, String> h : requestHeaders.entrySet()) {
                    if ("range".equalsIgnoreCase(h.getKey())) { range = h.getValue(); break; }
                }
            }
            long start = 0, end = length > 0 ? length - 1 : -1;
            boolean partial = false;
            if (length > 0 && range != null) {
                Matcher matcher = Pattern.compile("bytes=(\\d*)-(\\d*)").matcher(range.trim());
                if (matcher.matches()) {
                    String a = matcher.group(1), b = matcher.group(2);
                    if (!a.isEmpty()) start = Long.parseLong(a);
                    if (!b.isEmpty()) end = Math.min(length - 1, Long.parseLong(b));
                    if (a.isEmpty() && !b.isEmpty()) {
                        long suffix = Long.parseLong(b);
                        start = Math.max(0, length - suffix);
                    }
                    if (start > end || start >= length) return errorResponse(416, "Range Not Satisfiable");
                    partial = true;
                }
            }
            FileInputStream fileIn = new FileInputStream(pfd.getFileDescriptor());
            if (start > 0) fileIn.getChannel().position(start);
            final long remaining = length > 0 ? (end - start + 1) : -1;
            InputStream bounded = remaining >= 0 ? new LimitedInputStream(fileIn, remaining) : fileIn;
            String mime = getContentResolver().getType(uri);
            if (mime == null) mime = "application/octet-stream";
            Map<String, String> headers = new HashMap<>();
            headers.put("Accept-Ranges", "bytes");
            headers.put("Cache-Control", "no-store");
            headers.put("Access-Control-Allow-Origin", BASE_URL);
            headers.put("Access-Control-Allow-Headers", "Range");
            headers.put("Cross-Origin-Resource-Policy", "same-origin");
            if (remaining >= 0) headers.put("Content-Length", String.valueOf(remaining));
            if (partial) headers.put("Content-Range", "bytes " + start + "-" + end + "/" + length);
            final android.os.ParcelFileDescriptor closePfd = pfd;
            InputStream closing = new FilterInputStream(bounded) {
                @Override public void close() throws IOException {
                    try { super.close(); } finally { closePfd.close(); }
                }
            };
            return new WebResourceResponse(mime, null, partial ? 206 : 200,
                    partial ? "Partial Content" : "OK", headers, closing);
        } catch (Exception e) {
            try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
            return errorResponse(404, "Unable to read media");
        }
    }

    private static final class LimitedInputStream extends FilterInputStream {
        private long left;
        LimitedInputStream(InputStream input, long length) { super(input); left = length; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int value = super.read(); if (value >= 0) left--; return value;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = super.read(b, off, (int) Math.min(len, left)); if (n > 0) left -= n; return n;
        }
    }

    private boolean hasPermission(String permission) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasVisualAccess() {
        if (Build.VERSION.SDK_INT >= 34) {
            return hasPermission(Manifest.permission.READ_MEDIA_VIDEO)
                    || hasPermission(Manifest.permission.READ_MEDIA_IMAGES)
                    || hasPermission("android.permission.READ_MEDIA_VISUAL_USER_SELECTED");
        }
        if (Build.VERSION.SDK_INT >= 33) {
            return hasPermission(Manifest.permission.READ_MEDIA_VIDEO)
                    || hasPermission(Manifest.permission.READ_MEDIA_IMAGES);
        }
        return hasPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
    }

    private void requestMediaPermissions() {
        if (Build.VERSION.SDK_INT < 23) { sendMediaList(); return; }
        if (hasVisualAccess() && (Build.VERSION.SDK_INT < 33 || hasPermission(Manifest.permission.READ_MEDIA_AUDIO))) {
            sendMediaList(); return;
        }
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 34) {
            addIfMissing(need, Manifest.permission.READ_MEDIA_VIDEO);
            addIfMissing(need, Manifest.permission.READ_MEDIA_IMAGES);
            addIfMissing(need, Manifest.permission.READ_MEDIA_AUDIO);
            addIfMissing(need, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED");
        } else if (Build.VERSION.SDK_INT >= 33) {
            addIfMissing(need, Manifest.permission.READ_MEDIA_VIDEO);
            addIfMissing(need, Manifest.permission.READ_MEDIA_IMAGES);
            addIfMissing(need, Manifest.permission.READ_MEDIA_AUDIO);
        } else {
            addIfMissing(need, Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (need.isEmpty()) { sendMediaList(); return; }
        requestPermissions(need.toArray(new String[0]), MEDIA_PERMISSION_REQUEST);
    }

    private void addIfMissing(List<String> list, String permission) {
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) list.add(permission);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MEDIA_PERMISSION_REQUEST) {
            if (hasVisualAccess()) sendMediaList();
            else runOnUiThread(() -> evaluate("window.onNativeMediaDenied && window.onNativeMediaDenied();"));
        }
    }

    private void evaluate(String js) {
        if (webView != null) runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    private void sendMediaList() {
        Thread worker = new Thread(() -> {
        try {
            JSONArray result = new JSONArray();
            boolean legacy = Build.VERSION.SDK_INT < 33 || hasPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            boolean selected = Build.VERSION.SDK_INT >= 34 && hasPermission("android.permission.READ_MEDIA_VISUAL_USER_SELECTED");
            if (legacy || hasPermission(Manifest.permission.READ_MEDIA_VIDEO) || selected)
                queryMedia(result, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video");
            if (legacy || hasPermission(Manifest.permission.READ_MEDIA_IMAGES) || selected)
                queryMedia(result, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image");
            if (legacy || hasPermission(Manifest.permission.READ_MEDIA_AUDIO))
                queryMedia(result, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio");
            final int batchSize = 80;
            if (result.length() == 0) {
                evaluate("window.onNativeMedia && window.onNativeMedia([],true,true);");
            } else {
                for (int start = 0; start < result.length(); start += batchSize) {
                    JSONArray batch = new JSONArray();
                    int end = Math.min(result.length(), start + batchSize);
                    for (int i = start; i < end; i++) batch.put(result.getJSONObject(i));
                    boolean first = start == 0, last = end == result.length();
                    evaluate("window.onNativeMedia && window.onNativeMedia(" + batch.toString() + "," + first + "," + last + ");");
                }
            }
        } catch (Exception e) {
            String message = JSONObject.quote(e.getMessage() == null ? "Media scan failed" : e.getMessage());
            evaluate("window.onNativeMediaDenied && window.onNativeMediaDenied(); console.error(" + message + ");");
        }
        }, "PixelCut-MediaScan");
        worker.setPriority(Thread.NORM_PRIORITY - 1);
        worker.start();
    }

    private void queryMedia(JSONArray output, Uri collection, String type) {
        String[] projection;
        if ("video".equals(type)) {
            projection = new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED,
                    MediaStore.Video.VideoColumns.DURATION, MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT};
        } else if ("image".equals(type)) {
            projection = new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED,
                    MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT};
        } else {
            projection = new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED,
                    MediaStore.Audio.AudioColumns.DURATION};
        }
        String sort = MediaStore.MediaColumns.DATE_ADDED + " DESC";
        try (Cursor c = getContentResolver().query(collection, projection, null, null, sort)) {
            if (c == null) return;
            int idCol = c.getColumnIndex(MediaStore.MediaColumns._ID);
            int nameCol = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
            int mimeCol = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE);
            int durationCol = c.getColumnIndex(type.equals("audio") ? MediaStore.Audio.AudioColumns.DURATION : MediaStore.Video.VideoColumns.DURATION);
            int widthCol = c.getColumnIndex(MediaStore.MediaColumns.WIDTH);
            int heightCol = c.getColumnIndex(MediaStore.MediaColumns.HEIGHT);
            int dateCol = c.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED);
            while (c.moveToNext()) {
                long rowId = c.getLong(idCol);
                Uri content = ContentUris.withAppendedId(collection, rowId);
                String token = type.substring(0, 1) + "_" + UUID.randomUUID().toString().replace("-", "");
                mediaUris.put(token, content);
                String name = nameCol >= 0 && !c.isNull(nameCol) ? c.getString(nameCol) : type + " " + rowId;
                String mime = mimeCol >= 0 && !c.isNull(mimeCol) ? c.getString(mimeCol) : type + "/octet-stream";
                JSONObject o = new JSONObject();
                o.put("id", token); o.put("type", type); o.put("name", name); o.put("mime", mime);
                o.put("uri", content.toString()); o.put("url", BASE_URL + "/media/" + token);
                o.put("duration", durationCol >= 0 && !c.isNull(durationCol) ? c.getLong(durationCol) / 1000.0 : 0);
                o.put("width", widthCol >= 0 && !c.isNull(widthCol) ? c.getInt(widthCol) : 0);
                o.put("height", heightCol >= 0 && !c.isNull(heightCol) ? c.getInt(heightCol) : 0);
                o.put("dateAdded", dateCol >= 0 && !c.isNull(dateCol) ? c.getLong(dateCol) : 0);
                output.put(o);
            }
        } catch (Exception e) {
            android.util.Log.w("PixelCutAero", "Media query failed for " + type, e);
        }
    }

    private Uri registerMediaUri(String raw) {
        if (raw == null || raw.trim().isEmpty()) return null;
        try {
            Uri uri = Uri.parse(raw);
            if (!"content".equals(uri.getScheme()) || uri.getAuthority() == null) return null;
            String authority = uri.getAuthority();
            if (!("media".equals(authority) || authority.startsWith("com.android.providers.media"))) return null;
            String existing = reverseMediaIds.get(raw);
            if (existing != null) return mediaUris.get(existing) == null ? uri : mediaUris.get(existing);
            String token = "p_" + UUID.randomUUID().toString().replace("-", "");
            mediaUris.put(token, uri); reverseMediaIds.put(raw, token);
            return uri;
        } catch (Exception e) { return null; }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICK_REQUEST && fileChooserCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount(); results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileChooserCallback.onReceiveValue(results); fileChooserCallback = null;
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void showMediaLibrary() { runOnUiThread(() -> requestMediaPermissions()); }

        @JavascriptInterface
        public String getMediaUrl(String rawUri) {
            Uri uri = registerMediaUri(rawUri); if (uri == null) return "";
            String token = reverseMediaIds.get(rawUri);
            if (token == null) {
                for (Map.Entry<String, Uri> e : mediaUris.entrySet()) if (e.getValue().equals(uri)) { token = e.getKey(); break; }
            }
            return token == null ? "" : BASE_URL + "/media/" + token;
        }

        @JavascriptInterface
        public void openAppSettings() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            });
        }

        @JavascriptInterface
        public void setKeepScreenOn(boolean keep) {
            runOnUiThread(() -> {
                if (keep) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public boolean beginExport(String fileName, String mimeType) {
            synchronized (exportLock) {
                try {
                    closeExport(false);
                    String safe = fileName == null ? "PixelCut-Export" : fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (safe.isEmpty()) safe = "PixelCut-Export";
                    String mime = mimeType == null ? "application/octet-stream" : mimeType;
                    exportName = safe;
                    if (Build.VERSION.SDK_INT >= 29) {
                        boolean video = mime.startsWith("video/");
                        Uri collection = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                        values.put(MediaStore.MediaColumns.RELATIVE_PATH, video ? Environment.DIRECTORY_MOVIES + "/PixelCut Aero" : Environment.DIRECTORY_DOWNLOADS + "/PixelCut Aero Projects");
                        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                        exportUri = getContentResolver().insert(collection, values);
                        if (exportUri == null) return false;
                        exportStream = getContentResolver().openOutputStream(exportUri, "w");
                    } else {
                        File base = getExternalFilesDir(mime.startsWith("video/") ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOCUMENTS);
                        File dir = new File(base, "PixelCut Aero");
                        if (!dir.exists() && !dir.mkdirs()) return false;
                        legacyExportFile = new File(dir, safe);
                        exportStream = new FileOutputStream(legacyExportFile);
                    }
                    return exportStream != null;
                } catch (Exception e) {
                    android.util.Log.e("PixelCutAero", "beginExport", e); closeExport(false); return false;
                }
            }
        }

        @JavascriptInterface
        public boolean writeExportChunk(String base64) {
            synchronized (exportLock) {
                try {
                    if (exportStream == null || base64 == null) return false;
                    byte[] data = Base64.decode(base64, Base64.DEFAULT);
                    exportStream.write(data);
                    return true;
                } catch (Exception e) { android.util.Log.e("PixelCutAero", "writeExportChunk", e); return false; }
            }
        }

        @JavascriptInterface
        public boolean finishExport() {
            synchronized (exportLock) {
                try { closeExport(true); return true; }
                catch (Exception e) { android.util.Log.e("PixelCutAero", "finishExport", e); closeExport(false); return false; }
            }
        }

        @JavascriptInterface
        public void abortExport() { synchronized (exportLock) { closeExport(false); } }
    }

    private void closeExport(boolean publish) {
        try { if (exportStream != null) { exportStream.flush(); exportStream.close(); } } catch (Exception ignored) {}
        exportStream = null;
        if (Build.VERSION.SDK_INT >= 29 && exportUri != null) {
            try {
                if (publish) {
                    ContentValues values = new ContentValues(); values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(exportUri, values, null, null);
                } else getContentResolver().delete(exportUri, null, null);
            } catch (Exception e) { android.util.Log.e("PixelCutAero", "publish export", e); }
        } else if (legacyExportFile != null && !publish) {
            try { legacyExportFile.delete(); } catch (Exception ignored) {}
        } else if (legacyExportFile != null && publish) {
            final String path = legacyExportFile.getAbsolutePath();
            runOnUiThread(() -> Toast.makeText(this, "Export saved: " + path, Toast.LENGTH_LONG).show());
        }
        exportUri = null; legacyExportFile = null;
        if (publish && exportName != null) {
            final String saved = exportName;
            runOnUiThread(() -> evaluate("window.onNativeExportSaved && window.onNativeExportSaved(" + JSONObject.quote(saved) + ");"));
        }
        exportName = null;
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.evaluateJavascript("try{if(window.AndroidBridge){AndroidBridge.setKeepScreenOn(false)};if(typeof saveP==='function')saveP();if(typeof stop==='function')stop();}catch(e){}", null);
            webView.onPause();
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onPause();
    }

    @Override
    protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); }

    @Override
    public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("String(window.androidBack ? window.androidBack() : false)", value -> {
            if ("false".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onDestroy() {
        synchronized (exportLock) { closeExport(false); }
        if (webView != null) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
