# PixelCut Aero — Android / GitHub Actions

هذا المشروع يحوّل محرر PixelCut Motion الأصلي إلى تطبيق Android بغلاف Native مبني بـ Java وAndroid WebView محلي، مع الاحتفاظ بمحرك HTML/CSS/JavaScript والمؤثرات الأصلية بدلاً من إعادة تصميمه كمحرر قص بسيط.

## ما يتضمنه المشروع

- واجهة PixelCut Aero الأصلية ومحركها، مع التعديل على المصدر الأصلي داخل `VideoEditorApp/app/src/main/assets/index.html`.
- اختيار مكتبة الوسائط من Android بعد طلب الأذونات؛ فيديوهات وصور وملفات صوتية مع بحث وتصنيف ومعاينات مصغرة.
- بث ملفات MediaStore إلى المحرر عبر جسر Android محلي مع دعم HTTP Range، لتجنب تحميل ملفات الفيديو الكبيرة دفعة واحدة إلى JavaScript.
- أدوات المحرر الموجودة في المصدر: المقاطع والطبقات، Trim وSplit وSpeed وReverse وDuplicate وDelete، النصوص، المسارات الصوتية، المؤثرات، Keyframes وAuto-Key ومنحنيات الحركة وAMV وطبقات الفيديو وGLB/3D.
- تكبير/تصغير التايم لاين عبر Pinch وSlider وأزرار +/− وFIT، من دون تغيير مدة المشروع.
- سحب Playhead مباشرة مع تحديث المعاينة أثناء السحب.
- حفظ تلقائي ومحلي للمشاريع وقائمة المشاريع، وتصدير الفيديو إلى `Movies/PixelCut Aero` على Android 10+.
- تصدير واستيراد ملف مشروع `.pxa` يتضمن حالة المشروع ووسائطه، بالإضافة إلى ملف HTML الأصلي المرجعي.

## البناء عبر GitHub Actions

1. أنشئ مستودع GitHub جديداً.
2. فك ضغط ملف ZIP الذي استلمته، وارفع **محتوياته** إلى جذر المستودع، بحيث يصبح المجلد `VideoEditorApp` والمجلد `.github` ظاهرين مباشرة في الجذر.
3. نفّذ Commit وPush إلى الفرع `main`، أو افتح تبويب **Actions** وشغّل **PixelCut Aero Android APK** عبر **Run workflow**.
4. بعد نجاح التشغيل، افتح نتيجة الـ Workflow ثم قسم **Artifacts** ونزّل `pixelcut-aero-debug-apk`؛ يحتوي على `app-debug.apk`.

ملف workflow موجود في `.github/workflows/build-apk.yml`. لا يحتاج إلى فك ضغط ZIP داخل GitHub Actions، لأن بنية المستودع بعد فك الضغط محلياً هي بالفعل بنية المشروع المطلوبة.

## فتح المشروع في Android Studio

افتح مجلد `VideoEditorApp` كمشروع Gradle. يتطلب إعداد المشروع JDK 17 وAndroid SDK Platform 35 وAndroid Build Tools 35.0.0 وGradle 8.9. يعتمد بناء GitHub Actions على هذه النسخ المثبتة تلقائياً.

## ملاحظات تشغيل مهمة

- واجهة المحرر نفسها تبقى HTML/JavaScript محلياً داخل WebView بلا شريط متصفح أو موقع إنترنت؛ أما الأذونات ومكتبة الهاتف وحفظ الملفات فتتعامل معها طبقة Android Native.
- يتطلب عرض التأثيرات ومعالجتها دعماً مناسباً لـ WebGL في Android System WebView وتعريفات GPU بالجهاز.
- خيارات التصدير تعتمد على دعم WebCodecs/MediaRecorder وبرامج الترميز المتاحة على نسخة Android WebView والجهاز؛ محرك التصدير الأصلي يحاول MP4 ثم يستخدم مسار الوقت الحقيقي عند تعذّر المسار الدقيق.
- ملفات `.pxa` التي ينشئها هذا الإصدار تستخدم ZIP STORE غير المضغوط، ويُستورد هذا التنسيق من داخل التطبيق. قد يكون ملف المشروع كبيراً لأن الوسائط الأصلية تُضمّن داخله.
- هذا التسليم مشروع مصدر قابل للبناء وليس APK موقعاً جاهزاً. لم يكن Android SDK/Gradle متاحاً في بيئة إعداد الملفات هذه، لذلك لم أتمكن من إجراء assembleDebug محلياً؛ سيقوم GitHub Actions بتنفيذ البناء وإظهار أي خطأ بناء حقيقي في سجل التشغيل.
- لا يتضمن المشروع توقيع Release أو إعداد مفاتيح نشر Google Play؛ الـ Workflow ينتج Debug APK للتجربة.
