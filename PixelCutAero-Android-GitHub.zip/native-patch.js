/* PixelCut Aero Android integration. The original editor engine/UI above is retained. */
(function () {
  'use strict';
  const N_ORIGIN = 'https://appassets.androidplatform.net';
  let N_MEDIA = [];
  let N_FILTER = 'video';
  let N_SEARCH = '';
  let N_AUTO_SAVE = 0;
  let N_SCRUB = false;
  let N_PINCH = null;

  const nEsc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const nFmt = value => {
    const n = Math.max(0, Number(value) || 0);
    return Math.floor(n / 60) + ':' + (n % 60).toFixed(0).padStart(2, '0');
  };

  // Native MediaStore entries are registered as same-origin appasset URLs. They are
  // streamed by Android (including HTTP byte ranges) instead of copying full videos
  // into JavaScript memory.
  async function nAddMedia(item) {
    if (!item || !item.url || !item.id) throw new Error('Invalid device media item');
    const id = item.appId || ('device_' + item.id);
    if (M[id]) return M[id];
    const ty = item.type;
    if (!['video', 'image', 'audio'].includes(ty)) throw new Error('Unsupported media type');
    const m = {
      id, url: item.url, ty, name: item.name || 'Media', nativeUri: item.uri,
      mime: item.mime || (ty + '/mp4'), d: Number(item.duration) || (ty === 'image' ? 60 : 1),
      w: Number(item.width) || 1, h: Number(item.height) || 1, blob: null, native: true
    };
    if (ty === 'video' || ty === 'audio') {
      const e = document.createElement(ty === 'video' ? 'video' : 'audio');
      e.src = item.url;
      e.preload = 'metadata';
      e.playsInline = true;
      e.crossOrigin = 'same-origin';
      e.addEventListener('loadedmetadata', () => {
        if (Number.isFinite(e.duration) && e.duration > 0) m.d = e.duration;
        if (e.videoWidth) m.w = e.videoWidth;
        if (e.videoHeight) m.h = e.videoHeight;
        if (S.tab === 'Media' && S.fs) nRenderMedia();
      }, { once: true });
      m.el = e;
      wire(m);
    } else {
      const im = new Image();
      im.src = item.url;
      im.decoding = 'async';
      m.el = im;
      im.addEventListener('load', () => { m.w = im.naturalWidth || m.w; m.h = im.naturalHeight || m.h; }, { once: true });
    }
    M[id] = m;
    return m;
  }

  function nVisibleMedia() {
    const q = N_SEARCH.trim().toLowerCase();
    return N_MEDIA.filter(m => (N_FILTER === 'all' || m.type === N_FILTER) && (!q || (m.name || '').toLowerCase().includes(q)));
  }

  function nRenderMedia() {
    const root = document.getElementById('native-media-root');
    if (!root) return;
    const items = nVisibleMedia();
    const total = N_MEDIA.length;
    root.innerHTML = `<div class="nlib-head"><b>DEVICE LIBRARY</b><span>${items.length} / ${total} items</span></div>` +
      (items.length ? `<div class="nlib-grid">${items.map(m => {
        const mid = nEsc(m.id);
        const typ = m.type === 'video' ? 'VIDEO' : m.type === 'image' ? 'IMAGE' : 'AUDIO';
        const duration = m.type === 'video' || m.type === 'audio' ? nFmt(m.duration) : `${m.width || ''}×${m.height || ''}`;
        const glyph = m.type === 'video' ? '▶' : m.type === 'image' ? '▧' : '♫';
        const loaded = M['device_' + m.id] ? ' · READY' : '';
        const preview = m.type === 'video' ? `<video class="nmedia-preview" data-npreview="${mid}" muted playsinline preload="none"></video>` : (m.type === 'image' ? `<img class="nmedia-preview" data-npreview="${mid}" loading="lazy" alt="">` : `<span class="naudio-glyph">${glyph}</span>`);
        return `<div class="nmedia-card"><div class="nmedia-thumb ${m.type}">${preview}<small>${typ}</small></div><div class="nmedia-name" title="${nEsc(m.name)}">${nEsc(m.name)}</div><div class="nmedia-meta">${nEsc(duration)}${loaded}</div><div class="nmedia-actions"><button onclick="nUseMedia('${mid}',false)">+ CLIP</button>${m.type !== 'audio' ? `<button class="ac" onclick="nUseMedia('${mid}',true)">+ LAYER</button>` : ''}</div></div>`;
      }).join('')}</div>` : '<p class="hint">No items match this filter. Refresh the device library or change the filter.</p>');
    if (items.length && 'IntersectionObserver' in window) {
      const observer = new IntersectionObserver(entries => entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target, id = el.dataset.npreview, item = N_MEDIA.find(x => x.id === id);
        observer.unobserve(el); if (!item) return;
        el.src = item.url;
        if (el.tagName === 'VIDEO') {
          el.addEventListener('loadedmetadata', () => { try { el.currentTime = Math.min(.12, (el.duration || .5) / 3); } catch (_) {} }, { once: true });
        }
      }), { root: pan, rootMargin: '120px' });
      root.querySelectorAll('[data-npreview]').forEach(el => observer.observe(el));
    }
  }

  window.nUseMedia = async function (id, asLayer) {
    const item = N_MEDIA.find(x => x.id === id);
    if (!item) return toast('Media item is no longer available', 2500);
    try {
      const m = await nAddMedia(item);
      if (asLayer) useO(m.id); else use(m.id);
    } catch (e) { toast('Could not open media: ' + e.message, 4000); }
  };

  window.onNativeMedia = function (items, reset, finalBatch) {
    try {
      if (reset) { N_MEDIA = []; const root = document.getElementById('native-media-root'); if (root) root.innerHTML = '<p class=hint>Scanning device media…</p>'; }
      if (Array.isArray(items)) N_MEDIA.push(...items);
      if (finalBatch) {
        N_MEDIA.sort((a, b) => (Number(b.dateAdded) || 0) - (Number(a.dateAdded) || 0));
        if (S.tab === 'Media' && S.fs) nRenderMedia();
        toast('Device library loaded: ' + N_MEDIA.length + ' items', 2600);
      }
    } catch (e) { toast('Media library error: ' + e.message, 3500); }
  };
  window.onNativeMediaDenied = function () {
    const root = document.getElementById('native-media-root');
    if (root) root.innerHTML = '<div class="npermission"><b>MEDIA ACCESS IS OFF</b><p>Allow PixelCut Aero to access videos, images and audio in Android settings to display your device library here.</p><button class="ac" onclick="AndroidBridge.openAppSettings()">OPEN APP SETTINGS</button><button onclick="AndroidBridge.showMediaLibrary()">TRY AGAIN</button></div>';
  };
  window.onNativeExportSaved = function (name) { toast('Saved to device: ' + name, 4000); };

  // Keep the editor's existing media panel and visual language, while replacing
  // the browser-only file import workflow with an Android MediaStore library.
  const nOriginalPan = pan_;
  pan_ = function () {
    nOriginalPan();
    if (!window.AndroidBridge) return;
    if (S.tab === 'Media' && S.fs) {
      const oldImport = document.getElementById('fi');
      const oldFolder = oldImport && oldImport.parentElement;
      if (oldFolder) oldFolder.style.display = 'none';
      const oldRow = [...pan.children].find(e => e.classList && e.classList.contains('row'));
      if (oldRow) oldRow.style.display = 'none';
      if (!document.getElementById('native-media-toolbar')) {
        const bar = document.createElement('div');
        bar.id = 'native-media-toolbar';
        bar.innerHTML = `<div class="nlib-tools"><button class="ac" onclick="AndroidBridge.showMediaLibrary()">↻ DEVICE LIBRARY</button><button onclick="$('#fg').click()">+ 3D GLB</button></div><input id="native-media-search" type="text" placeholder="Search videos, images, audio…" autocomplete="off"><div class="nlib-filters"><button data-nfilter="video" class="on">VIDEOS</button><button data-nfilter="all">ALL</button><button data-nfilter="image">IMAGES</button><button data-nfilter="audio">AUDIO</button></div>`;
        pan.insertBefore(bar, pan.firstChild);
        bar.querySelector('#native-media-search').addEventListener('input', e => { N_SEARCH = e.target.value; nRenderMedia(); });
        bar.querySelectorAll('[data-nfilter]').forEach(b => b.addEventListener('click', () => {
          N_FILTER = b.dataset.nfilter;
          bar.querySelectorAll('[data-nfilter]').forEach(x => x.classList.toggle('on', x === b));
          nRenderMedia();
        }));
      }
      if (!document.getElementById('native-media-root')) {
        const root = document.createElement('div'); root.id = 'native-media-root'; pan.appendChild(root);
      }
      nRenderMedia();
    }
    if (S.tab === 'Export' && S.fs && !document.getElementById('native-project-tools')) {
      const tools = document.createElement('div');
      tools.id = 'native-project-tools';
      tools.innerHTML = `<h4>PROJECT FILE</h4><div class="row"><button class="ac" onclick="exportProjectPackage()">EXPORT PROJECT (.PXA)</button><button onclick="$('#pxa-input').click()">IMPORT PROJECT (.PXA)</button></div><input id="pxa-input" type="file" accept=".pxa,.zip,application/zip" hidden><p class="hint">A portable project package includes the edit, media files, layers, effects and keyframes.</p>`;
      pan.insertBefore(tools, pan.firstChild);
      tools.querySelector('#pxa-input').addEventListener('change', e => { if (e.target.files && e.target.files[0]) importProjectPackage(e.target.files[0]); e.target.value = ''; });
    }
  };

  // Native app auto-saves the current editor state to IndexedDB after committed
  // UI operations. The original explicit SAVE button remains available.
  const nOriginalUi = ui;
  ui = function () {
    nOriginalUi();
    if (window.AndroidBridge) {
      clearTimeout(N_AUTO_SAVE);
      N_AUTO_SAVE = setTimeout(() => { try { saveP(); } catch (_) {} }, 1100);
    }
  };

  // Persist device URI references for in-app saves; package exports below embed
  // the actual media bytes so a .pxa can also move to another device.
  saveP = async function () {
    const media = Object.values(M).map(m => ({
      id: m.id, ty: m.ty, name: m.name, blob: m.blob || null,
      nativeUri: m.nativeUri || null, mime: m.mime || (m.blob && m.blob.type) || '',
      d: m.d || 1, w: m.w || 1, h: m.h || 1
    }));
    await db('put', ($('#pn').value || 'Project 1').trim(), {
      s: snap(), asp: S.asp, xs: S.xs, media
    });
    toast('Project saved on this device');
    listP();
  };

  loadP = async function (name) {
    const p = await db('get', name); if (!p) return;
    stop();
    for (const k in M) { try { M[k].el && M[k].el.pause && M[k].el.pause(); } catch (_) {} delete M[k]; }
    for (const item of (p.media || p.m || [])) {
      try {
        if (item.nativeUri && window.AndroidBridge) {
          const url = AndroidBridge.getMediaUrl(item.nativeUri);
          if (!url) continue;
          await nAddMedia({ id: item.id.replace(/^device_/, ''), appId: item.id, type: item.ty, name: item.name, uri: item.nativeUri, url, mime: item.mime, duration: item.d, width: item.w, height: item.h });
        } else if (item.blob) {
          await addMedia(new File([item.blob], item.name, { type: item.mime || item.blob.type }), item.id);
        }
      } catch (e) { console.warn('Skipping unavailable project media', item.name, e); }
    }
    S.asp = p.asp || S.asp; if (p.xs) S.xs = p.xs;
    $('#pn').value = name; psize(); lo(p.s);
    Hs.length = 0; push(); tab('Clip');
  };

  // Save project snapshots with playhead and export settings as well.
  // The original snap() is kept as the history format; package export adds the
  // project-level settings in its own manifest.

  // MediaStore source audio is decoded from its appasset stream when the browser
  // originally selected-file Blob is not present.
  mixA = async function (tot, SR) {
    const oc = new OfflineAudioContext(2, Math.ceil(tot * SR), SR);
    const dec = async (m, rv) => {
      const source = m.blob ? await m.blob.arrayBuffer() : await (await fetch(m.url)).arrayBuffer();
      const b = AB[m.id] || (AB[m.id] = await oc.decodeAudioData(source.slice(0)));
      if (!rv) return b;
      return AB[m.id + 'r'] || (AB[m.id + 'r'] = (() => {
        const r = oc.createBuffer(b.numberOfChannels, b.length, b.sampleRate);
        for (let c = 0; c < b.numberOfChannels; c++) r.getChannelData(c).set(b.getChannelData(c).slice().reverse());
        return r;
      })());
    };
    const add = (b, when, off, d, rate, gain) => {
      const s = oc.createBufferSource(), gn = oc.createGain(); s.buffer = b; s.playbackRate.value = rate; gn.gain.value = gain;
      s.connect(gn); gn.connect(oc.destination); s.start(when, off, d);
    };
    let a = 0;
    for (const c of S.c) { const m = M[c.m]; if (m && m.ty === 'video') { try { add(await dec(m, c.rev), a, c.rev ? m.d - c.out : c.in, c.out - c.in, c.speed, c.vol); } catch (e) { console.warn('Audio from clip skipped', e); } } a += dur(c); }
    for (const o of S.o) { const m = M[o.m]; if (m && m.ty === 'video' && !o.hid) { try { add(await dec(m, false), o.start, o.in, o.out - o.in, o.speed, o.vol); } catch (e) {} } }
    if (S.mu) { try { const m = M[S.mu.m]; add(await dec(m, false), S.mu.start, 0, m.d, 1, S.mu.vol); } catch (e) {} }
    return oc.startRendering();
  };

  // Stream the rendered Blob to Android in small chunks. This avoids enormous
  // Base64 strings and stores the resulting file in Movies/PixelCut Aero or
  // Documents/PixelCut Aero Projects through MediaStore.
  dl = function (blob, filename) {
    if (!window.AndroidBridge || !blob) {
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename;
      document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000); return Promise.resolve();
    }
    return (async () => {
      let started = false;
      AndroidBridge.setKeepScreenOn(true);
      try {
        const mime = blob.type || (filename.toLowerCase().endsWith('.pxa') ? 'application/zip' : 'application/octet-stream');
        if (!AndroidBridge.beginExport(filename, mime)) throw new Error('Android could not create the output file');
        started = true;
        const chunkSize = 192 * 1024;
        for (let offset = 0; offset < blob.size; offset += chunkSize) {
          const bytes = new Uint8Array(await blob.slice(offset, Math.min(blob.size, offset + chunkSize)).arrayBuffer());
          let binary = '';
          for (let p = 0; p < bytes.length; p += 32768) binary += String.fromCharCode.apply(null, bytes.subarray(p, Math.min(bytes.length, p + 32768)));
          if (!AndroidBridge.writeExportChunk(btoa(binary))) throw new Error('Could not write export chunk');
          if (offset % (chunkSize * 4) === 0) await new Promise(resolve => setTimeout(resolve, 0));
        }
        if (!AndroidBridge.finishExport()) throw new Error('Android could not finish the output file');
        started = false;
      } catch (e) {
        if (started) { try { AndroidBridge.abortExport(); } catch (_) {} }
        throw e;
      } finally { try { AndroidBridge.setKeepScreenOn(false); } catch (_) {} }
    })().catch(e => { toast('Export failed: ' + e.message, 5000); throw e; });
  };

  // Portable .PXA project file: a standards-compliant ZIP with STORE entries.
  const nEncoder = new TextEncoder();
  const nCRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const nCrc32 = data => { let c = 0xffffffff; for (let i = 0; i < data.length; i++) c = nCRC[(c ^ data[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const nU16 = n => { const a = new Uint8Array(2); new DataView(a.buffer).setUint16(0, n, true); return a; };
  const nU32 = n => { const a = new Uint8Array(4); new DataView(a.buffer).setUint32(0, n >>> 0, true); return a; };
  async function nZipStore(entries) {
    const localParts = [], centralParts = []; let offset = 0;
    for (const entry of entries) {
      const name = nEncoder.encode(entry.name);
      const data = entry.data instanceof Uint8Array ? entry.data : new Uint8Array(entry.data);
      if (data.byteLength > 0xffffffff || offset > 0xffffffff) throw new Error('Project exceeds the ZIP32 4 GB limit.');
      const crc = nCrc32(data), flags = 0x0800;
      const lh = new Uint8Array(30 + name.length), lv = new DataView(lh.buffer);
      lv.setUint32(0, 0x04034b50, true); lv.setUint16(4, 20, true); lv.setUint16(6, flags, true);
      lv.setUint16(8, 0, true); lv.setUint16(10, 0, true); lv.setUint16(12, 0x21, true);
      lv.setUint32(14, crc, true); lv.setUint32(18, data.length, true); lv.setUint32(22, data.length, true);
      lv.setUint16(26, name.length, true); lv.setUint16(28, 0, true); lh.set(name, 30);
      localParts.push(lh, data);

      const ch = new Uint8Array(46 + name.length), cv = new DataView(ch.buffer);
      cv.setUint32(0, 0x02014b50, true); cv.setUint16(4, 20, true); cv.setUint16(6, 20, true);
      cv.setUint16(8, flags, true); cv.setUint16(10, 0, true); cv.setUint16(12, 0, true); cv.setUint16(14, 0x21, true);
      cv.setUint32(16, crc, true); cv.setUint32(20, data.length, true); cv.setUint32(24, data.length, true);
      cv.setUint16(28, name.length, true); cv.setUint16(30, 0, true); cv.setUint16(32, 0, true);
      cv.setUint16(34, 0, true); cv.setUint16(36, 0, true); cv.setUint32(38, 0, true);
      cv.setUint32(42, offset, true); ch.set(name, 46); centralParts.push(ch);
      offset += lh.length + data.length;
    }
    const centralSize = centralParts.reduce((sum, x) => sum + x.length, 0), count = entries.length;
    const end = new Uint8Array(22), ev = new DataView(end.buffer);
    ev.setUint32(0, 0x06054b50, true); ev.setUint16(4, 0, true); ev.setUint16(6, 0, true);
    ev.setUint16(8, count, true); ev.setUint16(10, count, true);
    ev.setUint32(12, centralSize, true); ev.setUint32(16, offset, true); ev.setUint16(20, 0, true);
    return new Blob([...localParts, ...centralParts, end], { type: 'application/zip' });
  }
  window.exportProjectPackage = async function () {
    try {
      const media = [], entries = [];
      const all = Object.values(M);
      for (let i = 0; i < all.length; i++) {
        const m = all[i];
        let blob = m.blob;
        if (!blob && m.url) { const response = await fetch(m.url); if (!response.ok) throw new Error('Cannot read ' + m.name); blob = await response.blob(); }
        if (!blob) continue;
        const path = `assets/${String(i).padStart(4, '0')}.bin`;
        entries.push({ name: path, data: new Uint8Array(await blob.arrayBuffer()) });
        media.push({ id: m.id, ty: m.ty, name: m.name, mime: m.mime || blob.type || 'application/octet-stream', d: m.d, w: m.w, h: m.h, path });
      }
      const manifest = {
        format: 'PixelCutAeroProject', version: 1, name: ($('#pn').value || 'PixelCut Project').trim(),
        state: JSON.parse(snap()), asp: S.asp, xs: S.xs, media
      };
      entries.unshift({ name: 'project.json', data: nEncoder.encode(JSON.stringify(manifest)) });
      toast('Packaging project media…', 3000);
      const archive = await nZipStore(entries);
      await dl(archive, (manifest.name.replace(/[\\/:*?"<>|]/g, '_') || 'PixelCut-Project') + '.pxa');
    } catch (e) { toast('Project export failed: ' + e.message, 6000); }
  };

  async function nReadZip(file) {
    const bytes = new Uint8Array(await file.arrayBuffer()), view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), files = {};
    let pos = 0;
    while (pos + 30 <= bytes.length && view.getUint32(pos, true) === 0x04034b50) {
      const method = view.getUint16(pos + 8, true), size = view.getUint32(pos + 18, true), nameLen = view.getUint16(pos + 26, true), extraLen = view.getUint16(pos + 28, true);
      const nameStart = pos + 30, dataStart = nameStart + nameLen + extraLen;
      if (method !== 0) throw new Error('This project ZIP uses compression not supported by this importer. Import a .PXA exported by PixelCut Aero.');
      if (dataStart + size > bytes.length) throw new Error('The project archive is incomplete.');
      const name = new TextDecoder().decode(bytes.subarray(nameStart, nameStart + nameLen));
      files[name] = bytes.slice(dataStart, dataStart + size);
      pos = dataStart + size;
    }
    return files;
  }

  window.importProjectPackage = async function (file) {
    if (!file) return;
    try {
      stop(); toast('Opening project package…', 4000);
      const files = await nReadZip(file), raw = files['project.json'];
      if (!raw) throw new Error('project.json is missing from this archive.');
      const p = JSON.parse(new TextDecoder().decode(raw));
      if (p.format !== 'PixelCutAeroProject' || !p.state || !Array.isArray(p.media)) throw new Error('This is not a PixelCut Aero project.');
      for (const k in M) delete M[k];
      for (const item of p.media) {
        const data = files[item.path]; if (!data) continue;
        const blob = new Blob([data], { type: item.mime || 'application/octet-stream' });
        await addMedia(new File([blob], item.name, { type: item.mime || blob.type }), item.id);
      }
      S.asp = p.asp || [16, 9]; if (p.xs) S.xs = p.xs;
      S.sel = null; $('#pn').value = p.name || file.name.replace(/\.pxa$/i, '');
      psize(); lo(JSON.stringify(p.state)); Hs.length = 0; push();
      await saveP(); tab('Clip'); toast('Project imported successfully', 4000);
    } catch (e) { toast('Project import failed: ' + e.message, 6000); }
  };

  // Timeline zoom: slider + pinch gesture, both preserving the time under the
  // finger/slider anchor. The zoom changes pixels-per-second only, never duration.
  const zoomBar = document.createElement('div');
  zoomBar.id = 'tlz';
  zoomBar.className = 'glass';
  zoomBar.innerHTML = `<span>TIMELINE</span><button id="tlz-out" aria-label="Zoom out">−</button><input id="tlz-slider" type="range" min="12" max="300" step="1" value="${S.z}"><button id="tlz-in" aria-label="Zoom in">＋</button><button id="tlz-fit">FIT</button><small id="tlz-value">${Math.round(S.z)} px/s</small>`;
  tl.parentElement.insertBefore(zoomBar, tl);
  const zoomSlider = zoomBar.querySelector('#tlz-slider');
  function nZoomAt(newZoom, clientX) {
    const rect = tl.getBoundingClientRect(), anchor = Math.max(0, Math.min(tl.clientWidth, clientX - rect.left));
    const time = (tl.scrollLeft + anchor) / S.z;
    S.z = Math.max(12, Math.min(300, Number(newZoom) || S.z));
    tlr(); tl.scrollLeft = Math.max(0, time * S.z - anchor);
    zoomSlider.value = String(Math.round(S.z));
    zoomBar.querySelector('#tlz-value').textContent = Math.round(S.z) + ' px/s';
    $('#ph').style.left = (S.T * S.z) + 'px';
    const hit = document.getElementById('phhit'); if (hit) hit.style.left = (S.T * S.z - 14) + 'px';
  }
  zoomSlider.addEventListener('input', e => nZoomAt(+e.target.value, tl.getBoundingClientRect().left + tl.clientWidth / 2));
  zoomBar.querySelector('#tlz-out').addEventListener('click', () => nZoomAt(S.z / 1.2, tl.getBoundingClientRect().left + tl.clientWidth / 2));
  zoomBar.querySelector('#tlz-in').addEventListener('click', () => nZoomAt(S.z * 1.2, tl.getBoundingClientRect().left + tl.clientWidth / 2));
  zoomBar.querySelector('#tlz-fit').addEventListener('click', () => nZoomAt(Math.max(12, Math.min(300, (tl.clientWidth - 36) / Math.max(.1, total()))), tl.getBoundingClientRect().left));
  tl.addEventListener('wheel', e => { if (e.ctrlKey) { nZoomAt(S.z * (e.deltaY > 0 ? .9 : 1.1), e.clientX); e.preventDefault(); } }, { passive: false });
  tl.addEventListener('touchstart', e => {
    if (e.touches.length === 2) { N_PINCH = { dist: Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY), x: (e.touches[0].clientX + e.touches[1].clientX) / 2 }; e.preventDefault(); }
  }, { passive: false });
  tl.addEventListener('touchmove', e => {
    if (N_PINCH && e.touches.length === 2) {
      const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      const x = (e.touches[0].clientX + e.touches[1].clientX) / 2;
      if (N_PINCH.dist > 0) nZoomAt(S.z * d / N_PINCH.dist, x);
      N_PINCH = { dist: d, x }; e.preventDefault();
    }
  }, { passive: false });
  ['touchend', 'touchcancel'].forEach(type => tl.addEventListener(type, e => { if (e.touches.length < 2) N_PINCH = null; }, { passive: true }));

  // Real-time playhead drag. The handle has a generous invisible hit area for
  // touch precision and calls the original renderer/decoder on every move.
  const playheadHit = document.createElement('div');
  playheadHit.id = 'phhit';
  tli.appendChild(playheadHit);
  function nScrubTo(clientX) {
    const r = tli.getBoundingClientRect();
    S.T = Math.max(0, Math.min(total(), (clientX - r.left) / S.z));
    S.play = 0; $('#bp').textContent = '▶';
    const px = S.T * S.z;
    $('#ph').style.left = px + 'px'; playheadHit.style.left = (px - 14) + 'px';
    $('#tm').textContent = fm(S.T) + '/' + fm(total());
    syncMedia(); render();
  }
  playheadHit.addEventListener('pointerdown', e => {
    e.preventDefault(); e.stopPropagation(); N_SCRUB = true;
    playheadHit.setPointerCapture(e.pointerId); nScrubTo(e.clientX);
  });
  playheadHit.addEventListener('pointermove', e => { if (N_SCRUB) { e.preventDefault(); nScrubTo(e.clientX); } });
  const nEndScrub = e => { if (!N_SCRUB) return; N_SCRUB = false; try { if (playheadHit.hasPointerCapture(e.pointerId)) playheadHit.releasePointerCapture(e.pointerId); } catch (_) {} };
  playheadHit.addEventListener('pointerup', nEndScrub);
  playheadHit.addEventListener('pointercancel', nEndScrub);
  playheadHit.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); });

  // Keep the exact timeline zoom when the viewport changes and keep the hitbox
  // synchronized with the animation-loop playhead.
  const nOriginalTick = tick;
  // tick is scheduled as a function callback; wrapping it is not required for
  // rendering. A light DOM observer handles the visual hitbox position.
  const nTimelineObserver = new MutationObserver(() => {
    const px = S.T * S.z; const hit = document.getElementById('phhit'); if (hit) hit.style.left = (px - 14) + 'px';
  });
  nTimelineObserver.observe($('#ph'), { attributes: true, attributeFilter: ['style'] });
  window.addEventListener('resize', () => { zoomSlider.value = String(Math.round(S.z)); zoomBar.querySelector('#tlz-value').textContent = Math.round(S.z) + ' px/s'; });

  window.androidBack = function () {
    if (S.fs) { S.fs = 0; pan_(); return true; }
    if (S.tab !== 'Media') { tab('Media'); return true; }
    if (S.play) { stop(); return true; }
    return false;
  };

  // Launch directly into the device media panel; the system permission dialog
  // then populates it with every item the user allowed the app to access.
  if (window.AndroidBridge) {
    S.tab = 'Media'; S.fs = 1; pan_();
    setTimeout(() => { try { AndroidBridge.showMediaLibrary(); } catch (e) { console.warn(e); } }, 650);
  }

  const nOriginalExp = exp;
  exp = async function () {
    try { if (window.AndroidBridge) AndroidBridge.setKeepScreenOn(true);
      const result = await nOriginalExp();
      if (!S.ex && window.AndroidBridge) AndroidBridge.setKeepScreenOn(false);
      return result;
    } catch (e) { if (!S.ex && window.AndroidBridge) AndroidBridge.setKeepScreenOn(false); throw e; }
  };
  const nOriginalEndEx = endEx;
  endEx = function () { nOriginalEndEx(); if (window.AndroidBridge) AndroidBridge.setKeepScreenOn(false); };
})();
